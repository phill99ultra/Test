cities = [
    {name: "Chisinau"},
    {name: "Chisinau"},
    {name: "Chisinau"},
    {name: "Chisinau"}
]
roads = [ 
    {from: 0, to: 1, distance: 50},
    {from: 0, to: 2, distance: 50},
    {from: 0, to: 3, distance: 50},
    {from: 0, to: 1, distance: 50}
];
// 1) functie("Chisinau", "Straseni") -> true/false
// afiseaza distanta
// 2) functie() de afisat orasele care sunt conectate prin cel mai scurt drum
// 3) bonus! se da un oras functie("Chisinau", 60) de afisat orasele din raza 