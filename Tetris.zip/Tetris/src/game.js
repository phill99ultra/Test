export default class Game {
    score = 0;
    lines = 0;
    html = '';
    map = [
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0]
    ];
        
    activePiece = {
        x : 0,
        y : 0,
        blocks : [
            [1, 1, 1],
            [0, 1, 0],
            [0, 0, 0]
        ]
    };
    showMap() {
        map = this.map;
        html = this.html;
        document.body.innerHTML = '';        
        for(row = 4; row < map.length; row++){
            for(cell =0 ; cell < map[row].length; cell++){
                // document.write($grid[$row][$cell])
                if(map[row][cell] == 0) {
                    html += '<span>&#9634;</span>'
                }
                if(map[row][cell] == 1) {
                    html += '<span>&#9640;</span>'
                }
                if(grid[row][cell] == 2) {
                    html += '<span>&#9635;</span>'
                }
            }
            html += '<br>';
        }
        document.body.innerHTML = html;
    }    
    movePieceLeft() {
        this.activePiece.x--;
        if (this.checkCollision()) {
            this.activePiece.x++;
        }
    };
    movePieceRight() {
        this.activePiece.x++;
        if (this.checkCollision()) {
            this.activePiece.x--;
        }
    };
    movePieceDown() {
        this.activePiece.y++;
        if (this.checkCollision()) {
            this.activePiece.y--;
            this.freezePiece();
        }
    };
    checkCollision() {
        const {y: pieceY, x: pieceX, blocks} = this.activePiece,
                                         map = this.map;
        for (let y = 0; y < blocks.length; y++ ) {
            for (let x = 0; x < blocks[y].length; x++) {
                if ( blocks[y][x] && 
                    ((map[pieceY + y] === undefined || map[pieceY + y][pieceX + x] === undefined) ||
                    map[pieceY + y][pieceX + x])
                ) {
                    return true
                }               
            }
        }
        return false
    };
    freezePiece() {
        const {y: pieceY, x: pieceX, blocks} = this.activePiece;
        for (let y = 0; y < blocks.length; y++ ) {
            for (let x = 0; x < blocks[y].length; x++) {
                if (blocks[y][x]) {
                    this.map[pieceY + y][pieceX + x] = blocks[y][x];
                }
            }
        }
    }
}