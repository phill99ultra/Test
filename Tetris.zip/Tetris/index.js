import Game from './src/game.js';
const game = new Game();
window.game = game;
console.log(game);